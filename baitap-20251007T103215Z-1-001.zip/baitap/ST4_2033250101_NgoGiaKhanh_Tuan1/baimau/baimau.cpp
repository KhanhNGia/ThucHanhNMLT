#include<stdio.h>
#include<conio.h>
//void main() {
//	printf("Chao ban!\n");
//	printf("Day la chuong trinh C dau tien. \n");
//	printf("Vui long nhap Enter de ket thuc.");
//	_getch();
//}
//---------------------------
//baimau2
//void main(){
//     int a;
//     printf("Nhap so nguyen a:");
//     scanf_s("%d", &a);
//     printf("So nguyen vua nhap la:%d", a);
//     _getch();
//}
//----------------------
//baimau3
//void main() {
//	int a, b, tong, hieu, tich;
//	float thuong;
//	printf("Nhap 2 so nguyen a va b:");
//	scanf_s("%d%d", &a, &b);
//	tong = a + b;
//	hieu = a - b;
//	tich = a * b;
//	thuong = (float)a / (float)b;
//	printf("tong=%d\n", tong);
//	printf("hieu=%d\n", hieu);
//	printf("tich=%d\n", tich);
//	printf("thuong=%.1f", thuong);
//	_getch();
//}
//--------------------
//baimau4
//void main() {
//	int ngayden, ngaydi, songay, sotuan, ngayle;
//	printf("Nhap ngay den va ngay roi di:");
//	scanf_s("%d%d", &ngayden, &ngaydi);
//	songay = ngaydi - ngayden;
//	printf("So ngay da o la: %d\n", songay);
//	sotuan = songay / 7;
//	printf("So tuan la:%d\n", sotuan);
//	ngayle = songay - sotuan * 7;
//	printf("So ngay le la:%d\n", ngayle);
//	int sotien = sotuan * 650 + ngayle * 100;
//	printf("So tien phai tra la:%d.", sotien);
//	_getch;
//}
//-------------------
//baimau5
//void main() {
//	int i = 1;
//	printf("i=%d\n", i);
//	int bt = 10 + ++i;
//	printf("ket qua cua bieu thuc 10 + ++i la:%d;gia tri cua i la: %d\n", bt, i);
//	i = 1;
//	printf("Khoi tao lai gia tri i=%d\n", i);
//	bt = 10 + i++;
//	printf("ket qua cua bieu thuc 10 + i++ la:%d;gia tri cua i la:%d\n", bt, i);
//	_getch();
//}
//-----------------------
//baimau6
//void main() {
//	int as;
//	printf("Nhap ma ASCII:");
//	scanf_s("%d", &as);
//	((as >= 65 && as <= 90) || (as >= 97 && as <= 122)) ? (printf("La chu cai")) : (printf("Ky tu:%c", as));
//	_getch();
//}
//---------------------------
//baiolop1
//void main() {
//	 printf("Que huong la chum khe ngot\n");
//	 printf("Cho con treo hai moi ngay\n");
//	 printf("Que huong la duong di hoc\n");
//	 printf("Con ve rop buom vang bay");
//	 _getch();
//}
//-------------------------
//baiolop2
//void main() {
//	float x;
//	printf("Nhap so thuc x:");
//	scanf_s("%f", &x);
//	int nguyen = (int) x;
//	printf("Phan nguyen cua x la :%d", nguyen);
//	_getch;
//}
//---------------------
//baiolop3
//#define PI 3.14
//void main() {
//	float r, cv, dt;
//	printf("Nhap ban kinh:");
//	scanf_s("%f", &r);
//	cv = 2 * r * PI;
//	dt = r * r * PI;
//	printf("chu vi hinh tron la: %.2f", cv);
//	printf("dien tich hinh tron la: %.2f", dt);
//	_getch();
//}
//----------------------
//baiolop4
//void main() {
//	int a, b, max;
//	printf("nhap 2 so nguyen a va b:");
//	scanf_s("%d%d", &a, &b);
//	max = (a > b) ? a : b;
//	printf("so lon nhat trong 2 so la:%d", max);
//	_getch;
//}
//------------------------------
//baiolop5
//void main() {
//	int a, b;
//	float thuong;
//	printf("Nhap 2 so nguyen a, b:");
//	scanf_s("%d%d", &a, &b);
//	thuong = (float)a / b;
//	printf("Thuong cua a chia cho b :%f\n", thuong);
//	int lamtron = (int)(thuong + 0.5);
//	printf("Lam tron thuong:%d\n", lamtron);
//	printf("In thuong voi 1 so thap phan:%.1f", thuong);
//}
//---------------------
//baiolop6
//#define DonGiaTuan 500000
//#define DonGiaNgay 100000
//void main() {
//	int a;
//	printf("Tinh tien thue phong\n");
//	printf("Don gia tuan:500000. Don gia ngay: 100000\n");
//	printf("Nhap vao tong so ngay da thue phong: ");
//	scanf_s("%d", &a);
//	int sotuan = a / 7;
//	int ngayle = a - sotuan * 7;
//	printf("So tuan ma khach thue:%d, so ngay khach thue: %d\n", sotuan, ngayle);
//	int tien = sotuan * DonGiaTuan + ngayle * DonGiaNgay;
//	printf("Tien phai tra:%d", tien);
//}
//--------------------------------------
//baiolop7
void main() {
	float a, b;
	int c;
	printf("Nhap so gio vao san:");
	scanf_s("%f", &a);
	printf("Nhap so gio ra san:");
	scanf_s("%f", &b);
	printf("So binh nuoc da uong:");
	scanf_s("%d", &c);
	float giochoi = b - a;
	printf("So gio da choi:%f ", giochoi);
	float tien = giochoi * 200.000 + c * 20.000;
	printf("So tien phai tra : %.3f", tien);
}